import Link from "next/link";
import { Button } from "@/components/ui/button";
import { ShoppingBag } from "lucide-react";

export default function Navbar() {
  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/5 bg-black/5 backdrop-blur justify-center">
      <div className="container mx-auto flex h-14 max-w-7xl items-center px-4">
        <Link href="/" className="mr-6 flex items-center space-x-2">
          <span className="text-xl font-bold bg-gradient-to-r from-blue-400 to-blue-600 bg-clip-text text-transparent">
            Reparatech.pro
          </span>{" "}
        </Link>
        <nav className="flex flex-1 items-center space-x-6 text-sm font-medium">
          <Link href="/" className="transition-colors hover:text-blue-400">
            Inicio
          </Link>
          <Link href="/" className="transition-colors hover:text-blue-400">
            Serviços
          </Link>
          <Link href="/" className="transition-colors hover:text-blue-400">
            Loja
          </Link>
          <Link href="/" className="transition-colors hover:text-blue-400">
            Sobre
          </Link>
        </nav>
        <div className="flex items-center space-x-4">
          <Link
            href="https://github.com/faccin27"
            target="_blank"
            rel="noreferrer"
          >
            <Button size="icon" className="hover:bg-blue-500 hover:text-black">
              <ShoppingBag className="h-4 w-4" />
              <span className="sr-only">Carrinho</span>
            </Button>
          </Link>
          <Button variant="ghost" size="sm">
            Contato
          </Button>
          <Button size="sm" variant="ghost" className="bg-blue-500/40">
            Login
          </Button>
        </div>
      </div>
    </header>
  );
}
